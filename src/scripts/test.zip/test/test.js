// 'use strict'
// const RequestParser=require("./../../src/core/RequestParser.js")
// const ResponseParser=require("./../../src/core/ResponseParser.js")
// const { default: axios } = require("axios")

// const {store_cookie} = require("./../../src/core/WebSpider.js")
// // var response = await axios({
// //     url:req.url,
// //     method:req.request.request_line.method,
// //     data:req.data,
// //     timeout:0,
// //     headers:{
// //       "Cookie":store_cookie[0]
// //     },
// // })
// async function Check(req=new RequestParser("http://127.0.0.1")){
//    return [true,["test only","dfasfsd"]]

// }

// module.exports=Check
//
//
//




